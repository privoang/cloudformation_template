# RDS

## Summary
This directory is used to store AWS RDS (Relational Database Service)
templates.


### aurora-validate.yml


### aurora.yml
Deploy an Aurora database server with the following options :
- Multi-AZ
- Encryption via KMS Key
- Restore from snapshot
- Outputs cluster endpoint and read-only endpoint

#### Caveats
- Per https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/UsingWithRDS.IAMDBAuth.html

*Availability for IAM Database Authentication*
_Aurora with MySQL compatibility, version 1.10 or higher. All instance classes are supported, except for db.t2.small._

### mysql-mariadb.yml


### oracle.yml


### postgre.yml


### sqlserver.yml

## Notes
