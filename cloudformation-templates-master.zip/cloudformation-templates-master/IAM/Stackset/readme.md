# What are StackSets

StackSets are a grouped deployment of the same Cloudformation template across regions and/or accounts.  They can be updated and have parameters set in similiar fashion to running a template in a single account.  They do require some roles be set up to be used across accounts.

## Setting up roles to use AWS Cloudformation StackSets

These templates are directly from AWS.  <https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/stacksets-prereqs.html>

Run <AWSStackSetAdministrationRole.yml> in the account you'll be deploying the cloudformation from.

```bash
aws --profile $PROFILE cloudformation create-stack \
 --stack-name "iam-AWSStackSetAdministrationRole" \
 --template-body file://AWSStackSetAdministrationRole.yml \
 --capabilities CAPABILITY_NAMED_IAM
```

Run <AWSCloudFormationStackSetAdministrationRole.yml> in each of the accounts you'll be targeting.

```bash
export CFAdminAccountId="000000000000"

aws --profile $TARGETPROFILE cloudformation create-stack --stack-name "iam-AWSCloudFormationStackSetAdministrationRole" \
 --template-body file://AWSCloudFormationStackSetAdministrationRole.yml \
 --parameters ParameterKey=AdministratorAccountId,ParameterValue="$CFAdminAccountId" \
 --capabilities CAPABILITY_NAMED_IAM
```

## Running a stackset from the Cloudformation console

Drop a txt file with a comma separated list of the aws accounts to be targeted into the cloudformation repo.  It can be referenced whenever a new stackset is run against those accounts.

![Submitting a Stackset](images/StackSetSubmit.gif "Submitting a Stackset")

![Review a Stackset](images/StackSetReview.gif "Review a Stackset")
