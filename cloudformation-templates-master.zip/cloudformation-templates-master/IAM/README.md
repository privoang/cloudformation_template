# IAM

## Summary


## Caveats


### iam-lucidchart.yml

This template will create an IAM managed policy using the policy provided by [LucidChart](https://lucidchart.zendesk.com/hc/articles/208018563).  You will need an account to view the policy.  

The managed policy is attached to a group and then the IAM user is tied to the group.  This is to allow another IAM user to easily add themselves to the group for debugging.

The CloudFormation CLI deployment is below.  This can be useful when looping on multiple accounts.

```aws --profile $PROFILE cloudformation create-stack --stack-name "iam-lucidchart"
 --template-body file://cloudformation-templates/IAM/iam-lucidchart.yml --capabilities CAPABILITY_NAMED_IAM
```

User keys are *not* created by this template.  They are generated via the CLI for secure distribution with the following command.

`aws --profile $PROFILE iam create-access-key --user-name lucidchart-read`


## Notes
