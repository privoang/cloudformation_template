#users.csv
#fullname, username, workspacebundleid

$awsaccount = "052327466433"
$workspacefilecounter=1
$workspacescounter=0

$outputfile = "workspaces-$awsaccount-$workspacefilecounter.yml"

cp workspacesbase.yml $outputfile
$usernames = Import-csv $args[0]

$usernames | ForEach-Object {
  $workspacescounter++

  $bundle = $_.workspacebundleid
  $user = $_.username
  echo "Workspace Number $workspacescounter : $user"

  echo "
    Workspace:
      Type: `"AWS::WorkSpaces::Workspace`"
      Properties:
        BundleId: $bundle
        DirectoryId: !Ref pDirectoryId
        UserName: $user
        RootVolumeEncryptionEnabled: true
        UserVolumeEncryptionEnabled: true
        VolumeEncryptionKey: pVolumeEncryptionKey
  " >> $outputfile

  if ( $workspacescounter -eq 200 ){
      $workspacescounter=0
      $workspacefilecounter++
      $outputfile = "workspaces-$awsaccount-$workspacefilecounter.yml"
      cp workspacesbase.yml $outputfile
  }


}
