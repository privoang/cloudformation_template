#users.csv
#fullname, username, workspacebundleid

$users = Import-csv $args[0]

$users | ForEach-Object {
  New-ADUser -Name ($_.fullname) -SamAccountName ($_.username)
}
