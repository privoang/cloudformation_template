# Phase 1 - Initialize Account & VPC w/ Privo Standard Baseline
## 1. Create Account/VPC
  Automatic - created


# Phase 2  - Configure Active Directory for Workspaces
## 2. Deploy Active Directory
  Prerequisite: After account is created, ask suppport which AZs have workspace
  aws support create-case --profile privo-dev --region us-east-1 \
       --service-code amazon-workspaces \
       --category-code general-guidance \
       --severity-code normal \
       --subject "workspace AZ availability" \
       --communication-body  "We need to know which availability zones can be used for workspaces in each region of this account." \
       --cc-email-addresses astone@privoit.com
  
  Automatic - CF template to create domain controllers is good to go.

## 3. Create account in AD for lookups
  SSM run doc - needs to be created
  New-ADUser -Name "AWS Workspace User Lookup" -GivenName "AWS Workspace" -Surname "User Lookup" -SamAccountName awsworkspaces -UserPrincipalName awsworkspaces@$DomainName -AccountPassword (Read-Host -AsSecureString "$ServicePassword")

## 4. Deploy AD connector
  aws --profile account ds connect-directory --name $DomainName --short-name "corp" --password "$ServicePassword" --size "Small" --description "AD" --connect-settings VpcId=string,SubnetIds=string,string,CustomerDnsIps=string,string,CustomerUserName=string

## 5. Get AD connector directory
  aws --profile account ds describe-directories --output json | jq -r .DirectoryDescriptions[].DirectoryId


# Phase 3 - Configure Workspaces
## 6. Register directory with Workspaces
  Done manually, no api yet.

## 7. Create Workspaces bundle
  This is done manually.

## 8. Generate user accounts
  Creates AD user accounts.  Passwords will be output to a file.
  ./create-AD-users.ps1 ./testusers.csv

## 9. Create Workspaces Template (max 200 resources per stack - can make multiple templates if necessary)
  Example csv for input and output cloudformation are in the samples directory.
  ./generate-workspaces-cloudformation.ps1 ./testusers.csv

## 10. Run workspaces template
  aws cloudformation --region=$region --profile=$profile create-stack \
  --stack-name=$workspacestackname \
  --capabilities=CAPABILITY_NAMED_IAM \
  --template-body=file://workspaces-$account-1.yml \
  --parameters ParameterKey=pBundle,ParameterValue="$bundleid" \
    ParameterKey=pDirectoryId,ParameterValue="$directoryid" \
    ParameterKey=pVolumeEncryptionKey,ParameterValue="$encryptionkeyarn"
