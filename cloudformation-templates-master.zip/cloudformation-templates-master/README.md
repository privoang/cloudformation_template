# CloudFormation Templates

This repository contains Privo's standard Cloudformation templates for various AWS resources.

If you have a template that will be deployed at many clients, it should be considered for submission to this repo.  Otherwise, it can be stored in various client directories in the [privoit/Cloudformation](https://github.com/privoit/CloudFormation) repo.

## Table Of Contents

- [CloudFormation Templates](#cloudformation-templates)
  - [Table Of Contents](#table-of-contents)
  - [Pre-commit](#pre-commit)
  - [Template Standards](#template-standards)
    - [Keeping Templates Clear](#keeping-templates-clear)
    - [Markdown](#markdown)
      - [Examples](#examples)
  - [Style Guide](#style-guide)
    - [Language](#language)
    - [Parameters](#parameters)
    - [Resources](#resources)
    - [Strings](#strings)
    - [Cloudformation Example Templates](#cloudformation-example-templates)
  - [Repository Additions](#repository-additions)

## Pre-commit

Pre-commit has been set up with some basic hooks, including a Cloudformation linter from AWS.
Information on how to install pre-commit is available here: <https://pre-commit.com/#install>

Occassionally, pre-commit may block legitimate changes. You can add ignore clauses to your template's metadata (https://github.com/aws-cloudformation/cfn-python-lint#template-based-metadata) or try updating the revision (https://github.com/aws-cloudformation/cfn-python-lint/releases) referenced in the pre-commit configuration.

## Template Standards

Templates commited to this repository will have expectations of high reuse.  Template uses need to be clear and well documented so our teams (and sometimes, customers) can pick them up and run with them.  Excellent documentation and templates here can expedite project and operations tasks and provide high quality deliverables for our customers.

### Keeping Templates Clear

1. Keep it simple - minimal reusable resources and use maps to simplify parameters
2. Description - Robust multi-line description at top of template if needed
3. Declare AllowedValues, AllowedPatterns, and/or rule assertions - don't leave room for parameter mistakes
4. Listen to comments from your peers - feedback is key to improving ourselves and our work

### Markdown

Pull requests should include a markdown named `README.md` that includes the following:

- Basic description
- Requirements and dependencies
- Instructions/example deployment
- Reference links/documentation that may be helpful

Diagrams are optional, but if included, please have both the image file and a `.pptx` file of the diagram included in the pull request.  This allows for easy updating and importing into multiple diagraming platforms.

If you're new to markdown, fear not, GitHub has a 3 minute read on [Mastering Markdown](https://guides.github.com/features/mastering-markdown/)!  In addition to that, if you're a VSCode user check out the `markdownlint` to extension to spot check your syntax.

#### Examples

Use the following as reference points for creating your markdown.

- [privoit/emr-hail](https://github.com/privoit/emr-hail)
- [privoit/datadog](https://github.com/privoit/datadog)
- [privoit/Cloudformation/reveleer/archived](https://github.com/privoit/CloudFormation/tree/master/reveleer/archived)
- [privoit/cloudformation-templates/lambda/s3-tag-on-putobject](https://github.com/privoit/cloudformation-templates/tree/repo-standards-update/lambda/s3-tag-on-putobject)
- [privoit/cloudformation-templates/route53/outbound-resolver](https://github.com/privoit/cloudformation-templates/tree/master/route53/outbound-resolver)

## Style Guide

Please follow the Privo IT Style Guide when contributing.  Please review pull requests to ensure they follow the Style Guide, and remember that the Style Guide is *always* up for discussion!

### Language

YAML is preferred over JSON wherever possible.

### Parameters

Parameters should always be prefixed with a lowercase "p".

ex.

```yaml
pAvailabilityZone1:
  Type: AWS::EC2::AvailabilityZone::Name
  Default: us-east-1a
```

### Resources

Resources should always be prefixed with a shorthand abbreviation indicating the type of AWS resource.

ex.

```yaml
snsTopicPrivoAwsAlertsProduction:
  Type: "AWS::SNS::Topic"
  Condition: CondPrivoSupportTeamProduction
  Properties:
    DisplayName: "Privo-AWS-Production-Alerts "
    Subscription:
      - Protocol: "email"
        Endpoint: "aws@privoit.com"
```

### Strings

Enclose `String` types in double quotes.

ex.

```yaml
pDeliveryFrequency:
  Description: "The frequency with which AWS Config delivers configuration snapshots"
  Type: "String"
  Default: "One_Hour"
```

### Cloudformation Example Templates

If you're making a new cloudformation template, you can grab the [stack-skeleton.yml](docs/stack-skeleton.yml) or [stack-cloudformation-examples.yml](docs/stack-cloudformation-examples.yml) from the root of this repo.  The example template has an example of using a map, an import, declaring rules for parameter validation, using a conditional based on the value of a parameter, and allowedpattern examples.

## Repository Additions

To contribute to this project:

1. Create a local branch

    ```bash
    git checkout -b my-new-template-branch
    ```

2. Make your local changes, include new or updated documentation, and commit to your local branch

    ```bash
    git add file_xyz.yaml
    git commit -m "Added template xyz"
    ```

3. Push your local branch to the remote

    ```bash
    git push --set-upstream origin my-new-template-branch`
    ```

4. In the GitHub console create a pull request for your branch.   Assign yourself, and, if you want someone to review it or if you want to get it merged, Add **privoit/engineering** for review, and tag it appropriately.

    ![submit a PR](docs/images/submitPRanimated.gif)

5. The PR has to be approved by **2 people _with comments_**.

6. Once approved the **PR owner** will **squash and merge** the PR in the GitHub console and **delete the branch**.

7. In your local repository, you can update from the new head of the master branch and [prune](https://stackoverflow.com/questions/36082788/what-is-git-pruning) the deleted remote branch.

    ```bash
    git checkout master
    git pull
    git fetch -p
    ```
