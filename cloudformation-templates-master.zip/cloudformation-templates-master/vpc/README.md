- [Network Cloudformation](#network-cloudformation)
  - [Summary](#summary)
  - [Caveats](#caveats)
  - [Templates](#templates)
    - [vpc.yml](#vpcyml)
    - [vpc-transitgateway.yml](#vpc-transitgatewayyml)
    - [vpc-tgw-routing-and-nacls.yml](#vpc-tgw-routing-and-naclsyml)
    - [vpc-tgw-attachment.yml](#vpc-tgw-attachmentyml)
  - [Common Deployments](#common-deployments)
    - [Deploying a network with a transit gateway](#deploying-a-network-with-a-transit-gateway)
    - [DNS Considerations](#dns-considerations)

# Network Cloudformation

## Summary

Templates related to deploying a single or multiple VPCs, across regions, and AWS accounts.

## Caveats

These are best used from the ground up and may need customization depending on customers requirements.

## Templates

### [vpc.yml](vpc.yml)

The Standard Privo VPC. Through blood, sweat, tears, and a plethora of deployments, this bad boy is ready for any kind of network shenanigans.

- Instructions and Explanation [here](docs/vpc.md)

### [vpc-transitgateway.yml](vpc-transitgateway.yml)

Deploys a transit gateway and optionally share with other AWS Accounts.

- Instructions [here](docs/vpc-transitgateway.md)

### [vpc-tgw-routing-and-nacls.yml](vpc-tgw-routing-and-nacls.yml)

Using outputs from a specified vpc stack, this adds nacls and routes for up to 15 network cidrs. You can create multiple stacks for the same vpc if you have more than 15 cidrs.

- Instructions [here](docs/vpc-tgw-routing-and-nacls.md)

### [vpc-tgw-attachment.yml](vpc-tgw-attachment.md)

Using outputs from a specified vpc stack, this adds nacls and routes for up to 15 network cidrs. You can create multiple stacks for the same vpc if you have more than 15 cidrs.

- Instructions [here](docs/vpc-tgw-routing-and-nacls.md)

## Common Deployments

### Deploying a network with a transit gateway

1. VPCs

   [vpc template](vpc.yml)

   [vpc directions](docs/vpc.md)

2. Deploy Transit Gateway via template

   [tgw template](vpc-transitgateway.yml)

   [tgw directions](docs/vpc-transitgateway.md)

   Accept the share invitation in each account (manual step) after specifying them in the template, the invites will show up here - <https://console.aws.amazon.com/ram/home?region=us-east-1#SharedResourceShares:> You'll have to switch roles into each account to accept all the invites.

3. Attach TGW to each VPC

   [tgw-attachment template](vpc-tgw-attachment.yml)

   [tgw-attachment directions](docs/vpc-tgw-attachment.md)

4. Add transit gateway VPC cidrs to routes and nacls for each VPC

   [tgw-routes-and-nacls template](vpc-tgw-routing-and-nacls.yml)

   [tgw-routes-and-nacls directions](docs/vpc-tgw-routing-and-nacls.md)

Note: Security Groups are leaned on to manage ingress permissions as we're allowing everything in each VPC via NACLs and Routes over the transit gateway.

### DNS Considerations

If systems are going to be part of an Active Directory domain or utilize DNS servers outside of AWS, set up a Route53 DNS Resolver.

1. Deploy the Route53 DNS Resolver template in the same account as the shared transit gateway

   [outbound-resolver template](../route53/outbound-resolver/route53-outbound-resolver.yml)

   [outbound-resolver directions](../route53/outbound-resolver/readme.md)

   If you shared the resolver with other accounts, you'll need to accept the share invitation in each account like you did for the transit gateway.

2. Attach the Route53 Resolver Rule to each VPC that needs DNS resolution for the specified domain

Note: The Route53 DNS Resolver deploys ENIs to a VPC, they'll need to be able to access the DNS servers specified in the template. Adjust Routes, NACLs, Security groups, firewalls, etc as necessary.
