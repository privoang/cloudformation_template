# Transit Gateway Routes and NACLs

## Summary

For all route tables in the specified VPC, this will add a route to the transit gateway for the provided cidrs.

A NACL Rule will be added to each NACL list for each cidr.

## Requirements

1. The VPC Stackname that is specified need to exist in the account and region this template is run and have outputs for all import function calls in the template.
2. The Transit gateway needs exist or be shared with the account and in the same region as the VPC.
3. NACL Rules start at the Prefix number plus "01", these can not overlap with existing rules.

## Pitfalls

Unknown.
