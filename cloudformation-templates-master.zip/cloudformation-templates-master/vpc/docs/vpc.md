# VPC

## Summary

Privo's standard VPC - 2 Availability Zones, 3 Subnet Tiers - Public, Private/App, Private Data

## Details

Assumes 2 AZs only.  Internet Gateways, NAT Gateways, S3 and DynamoDB endpoints included.

### Routing

### NACLs


## Design Notes

Find reference we sent BASF and put that here
