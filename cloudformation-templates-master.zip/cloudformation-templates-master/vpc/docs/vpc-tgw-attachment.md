# Transit Gateway VPC Attachment

## Summary

Attaches a VPC to a transit gateway.

## Requirements

1. Transit Gateways drop an ENI in a single subnet in each AZ of a VPC.  This template assumes a 2 AZ VPC.
2. VPC is deployed.
3. Transit Gateway is shared or deployed in the same account and region as the VPC.

## Pitfalls

Unknown.
