# Transit Gateway

## Summary

Creates a Transit Gateway for sharing across AWS Accounts or using in a single account.

## Requirements

None.

## Pitfalls

Unknown.

## Details

Configured for easily sharing with 15 different AWS Accounts.
