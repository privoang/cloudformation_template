# S3

## Summary

Cloudformation templates to create various S3 buckets.

## s3-SSE.yml

## s3-alblogs.yml

## s3-ftpconfig.yaml

## s3-lifecycle.yml

## s3-logging-bucket.yml

This creates a logging bucket.  This means a bucket with LogDeliveryWrite Access Control turned on.  This bucket can be used by other services to log to.

## s3-restrict-access-to-named-users-bucket-policy.json

## s3-staticwebsite.yml

## s3-with-logging.yml

This template will create a basic S3 bucket that will log requests to a logging bucket.

### Notes

In order to use this template, you first need to create a logging bucket.  This is done this way so that multiple buckets can log to the same logging bucket instead of having a 1 to 1 relationship.  A logging bucket needs to have the LogDeliveryWrite Access Control turned on.  This can be done using the [s3-logging-bucket.yml](#s3-logging-bucket.yml) template.

## s3-with-replication.yml

## s3.yml

This template creates a very basic S3 bucket without any encryption.
