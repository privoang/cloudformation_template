## Template: code-pipeline-code-deploy.yml

Creates a GitHub triggered CodePipeline to CodeDeploy workflow.  An encrypted S3 bucket is created for artifacts.  The [deployment configuration](https://docs.aws.amazon.com/codedeploy/latest/userguide/deployment-configurations.html) for this example is CodeDeployDefault.OneAtATime.

In order to use GitHub as a trigger, a Personal Access Token (PAT) must be created with access to the private repository and the ability to adjust repository hooks.  

PAT Creation Example
![GitHub PAT Creation](images/github-PAT.gif)

#### Complete Pipeline Flow

A push to the GitHub branch triggers a webhook that calls CodePipeline.  The source is pulled from GitHub by Codepipeline, bundled, and put in an encrypted at rest S3 bucket for a hand-off to the staging deployment group.

The staging deployment group has rollbacks enabled, and is pushed to a single EC2 instance.  This is designated by the `Name:` tag.

If the staging deployment is successful, it is manually gated in production.  Upon approval, the production deployment group will deploy to an auto scaling group.  A specific target group is referenced here and CodeDeploy will manage the load balancing during deployment.  Auto rollbacks are also an option here.


### Considerations

CodeDeploy can only manage a single target group.  If using an HTTPS redirect, it's better to use the HTTPS related target group over an HTTP if both exist.  The number of users hitting the target group on standard HTTP will be extremely low.
