# Template: code-pipeline-sam-github.yml

Creates a GitHub triggered CodePipeline to SAM deploy workflow.  An encrypted S3 bucket is created for artifacts.  

In order to use GitHub as a trigger, a Personal Access Token (PAT) must be created with access to the private repository and the ability to adjust repository hooks.  

## Complete Pipeline Flow

A push to the GitHub branch triggers a webhook that calls CodePipeline.  The source is pulled from GitHub by Codepipeline, the SAM app is bundled, pushed to s3, and codepipeline deploys cloudformation updates for SAM.

## Example

The privo SAM repo, <https://github.com/privoit/sam>, is available for testing and configuring AWS SAM.
