## General notes

This stack will deploy a CodePipeline, CodeBuild project, static S3 Bucket for website, CloudFront distribution, and IAM resources for automated static website CICD. Create an appropriate buildspec.yml for building code, syncing to S3, and invalidating CloudFront.

## Requirements

- A Github OATH token with "repo" access and the ability to clone the files.
- The root directory of the Git repo should have a file named `buildspec.yml` that contains the commands needed to build the app (sample in this repo).
- ACM cert with required CNAMEs included

## Configuration Options

If you use the Amazon Linux 2 (AL2) standard image version 1.0 or later, or the Ubuntu standard image version 2.0 or later, you must specify at least one runtime and its version in the runtime-versions section of your buildspec file.

https://docs.aws.amazon.com/codebuild/latest/userguide/sample-runtime-versions.html