# Codepipeline S3 to ECS

## Template Requirements

ECS Cluster, Service, and Task Definition for pipeline target
S3 bucket with versioning enabled for pipeline source

## Test your example

"tomcat", below can be whatever you want to call your image.

While in the example directory, run:

```bash
docker build . -t tomcat
docker run -p 80:8080 -t tomcat
```

Test the local docker image

```bash
curl http://127.0.0.1
```

## Test the pipeline

Zip up the example and upload it to the s3 bucket and key that has or will be specified in the code-pipeline-s3-to-ecs.yml template.

From within the example directory, run:

```bash
zip ../example.zip *

aws s3 cp ../example.zip s3://YOURS3BUCKET/example.zip
```
