region="us-east-1"
profile="privo-dev"
stackname=$1

keyname="pri-dev-2018-07-06"

vpccidr="172.20.0.0/16"
vpcid="vpc-707d8b0a"
appsubnet1="subnet-5c04ab72"
appsubnet2="subnet-b9acdcf3"

clustername=$stackname
groupname="$clustername-workers"
instancetype="m5.large"

environment="production"

aws cloudformation --region=$region --profile=$profile create-stack \
--stack-name=$stackname \
--capabilities=CAPABILITY_NAMED_IAM \
--template-body=file://eks-cluster.yml \
--parameters ParameterKey=pClusterName,ParameterValue="$clustername" \
  ParameterKey=pVPCID,ParameterValue="$vpcid" \
  ParameterKey=pVPCCidr,ParameterValue="$vpccidr" \
  ParameterKey=pPrivateSubnet1,ParameterValue="$appsubnet1" \
  ParameterKey=pPrivateSubnet2,ParameterValue="$appsubnet2" \
  ParameterKey=pKeyName,ParameterValue="$keyname" \
  ParameterKey=pNodeInstanceType,ParameterValue="$instancetype" \
  ParameterKey=pNodeGroupName,ParameterValue="$groupname" \
  ParameterKey=pTagEnvironment,ParameterValue="$environment"

aws cloudformation --region=$region --profile=$profile wait stack-create-complete --stack-name $stackname

endpoint=$(aws cloudformation --profile=$profile --region=$region describe-stacks --stack-name "$stackname"  --query 'Stacks[0].Outputs[?OutputKey==`Endpoint`].OutputValue' --output text)
caauthority=$(aws cloudformation --profile=$profile --region=$region describe-stacks --stack-name "$stackname"  --query 'Stacks[0].Outputs[?OutputKey==`CertificateAuthorityData`].OutputValue' --output text)

export KUBECONFIG=~/.kube/config-$clustername
cat kube-config >  ~/.kube/config-$clustername

#this syntax is so it will work on macos
sed -i'.original' -e "s,<cluster-name>,$clustername,g" ~/.kube/config-$clustername
rm -f ~/.kube/config-$clustername.original
sed -i'.original' -e "s,<endpoint-url>,$endpoint,g" ~/.kube/config-$clustername
rm -f ~/.kube/config-$clustername.original
sed -i'.original' -e "s,<base64-encoded-ca-cert>,$caauthority,g" ~/.kube/config-$clustername
rm -f ~/.kube/config-$clustername.original

kubectl get svc

eksworkerrole=$(aws cloudformation --profile=$profile --region=$region describe-stacks --stack-name "$stackname"  --query 'Stacks[0].Outputs[?OutputKey==`EKSWorkerRole`].OutputValue' --output text)
awsaccountid=$(aws sts --profile=$profile --region=$region get-caller-identity --output text --query 'Account')

cat  aws-auth-cm.yaml > aws-auth-cm-$clustername.yaml
sed -i'.original' -e "s,<ARN of instance role (not instance profile)>,$eksworkerrole,g" aws-auth-cm-$clustername.yaml
rm -f aws-auth-cm-$clustername.yaml.original
sed -i'.original' -e "s,<AWSAccountID>,$awsaccountid,g" aws-auth-cm-$clustername.yaml
rm -f aws-auth-cm-$clustername.yaml.original

kubectl apply -f aws-auth-cm-$clustername.yaml

kubectl get nodes
