# ALB Failover - Redirect All Traffic on Target Group Failure

This template will create a CloudWatch Alarm, SNS Topic, and Lambda function.  There is also an optional SNS topic for function invocation errors.

The alarm monitors the HealthHostCount of a primary target group.  If the HealthHostCount drops to 0 the alarm will publish to an SNS topic. The SNS topic will invoke the Lambda function and optionally notifiy an email address.

On **ALERT** the Lambda function will insert an ALB listener rule to redirect all traffic to **either** another backup Target Group or a 302 to another URL.  On **recovery** of the primary target group, the function will remove the previously inserted redirect rule.

With short target group health check times the full failover time is roughly 90 seconds.  This is an alternative to Route53 failover logic which can take several minutes.

![Workflow](docs/flow.png)

* pptx source is located in the [docs](docs/) directory.

## Considerations

* The minimum monitoring period for the CloudWatch Metric `AWS/*` namespace is 60 seconds.  This is the primary limiter of failover speed.
* AWS Events do not publish an event for changes in healthy host count.  This was investigated as a faster potential function trigger.
* Health check intervals matter here.   A shorter health check interval (sub 1 minute) will result in faster function invocation.
* The optional SNS recipient may need to subscribe prior to successful stack deployment.

## Test Events

The following CloudWatch Events can be used to test functionality directly in Lambda.  The SNS object `Subject` and `Message` entries are intentionally escaped.

### ALARM

```json
{
    "Records": [{
        "EventSource": "aws:sns",
        "EventVersion": "1.0",
        "EventSubscriptionArn": "arn:aws:sns:us-east-1:999999999999:albtest-sns-1JQJXK25KSW7E:3bf6f089-be25-4e0d-ac95-bdf33fda32bd",
        "Sns": {
            "Type": "Notification",
            "MessageId": "67e3f061-7127-5d28-bfa4-a5865480ed69",
            "TopicArn": "arn:aws:sns:us-east-1:999999999999:albtest-sns-1JQJXK25KSW7E",
            "Subject": "ALARM: \"targetgroup-healthy-host-count\" in US East (N. Virginia)",
            "Message": "{\"AlarmName\":\"targetgroup-healthy-host-count\",\"AlarmDescription\":\"Target Group Healthy Host Monitor\",\"AWSAccountId\":\"999999999999\",\"NewStateValue\":\"ALARM\",\"NewStateReason\":\"Threshold Crossed: 1 out of the last 1 datapoints [0.0 (02/09/19 14:11:00)] was less than or equal to the threshold (0.0) (minimum 1 datapoint for OK -> ALARM transition).\",\"StateChangeTime\":\"2019-09-02T14:12:55.947+0000\",\"Region\":\"US East (N. Virginia)\",\"OldStateValue\":\"OK\",\"Trigger\":{\"MetricName\":\"HealthyHostCount\",\"Namespace\":\"AWS/ApplicationELB\",\"StatisticType\":\"Statistic\",\"Statistic\":\"AVERAGE\",\"Unit\":null,\"Dimensions\":[{\"value\":\"targetgroup/dynamoc/1cbc7a282793395f\",\"name\":\"TargetGroup\"},{\"value\":\"app/aptest/9c29daf5581bdc46\",\"name\":\"LoadBalancer\"}],\"Period\":60,\"EvaluationPeriods\":1,\"ComparisonOperator\":\"LessThanOrEqualToThreshold\",\"Threshold\":0.0,\"TreatMissingData\":\"- TreatMissingData: notBreaching\",\"EvaluateLowSampleCountPercentile\":\"\"}}",
            "Timestamp": "2019-09-02T14:12:55.995Z",
            "SignatureVersion": "1",
            "Signature": "VvX...FQ==",
            "SigningCertUrl": "https://sns.us-east-1.amazonaws.com/SimpleNotificationService-6aad65c2f9911b05cd53efda11f913f9.pem",
            "UnsubscribeUrl": "https://sns.us-east-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:us-east-1:999999999999:albtest-sns-1999999999999:3bf6f089-be25-4e0d-ac95-bdf33fda32bd",
            "MessageAttributes": {}
        }
    }]
}
```

### RECOVERY

```json
{
    "Records": [{
        "EventSource": "aws:sns",
        "EventVersion": "1.0",
        "EventSubscriptionArn": "arn:aws:sns:us-east-1:999999999999:albtest-sns-1JQJXK25KSW7E:3bf6f089-be25-4e0d-ac95-bdf33fda32bd",
        "Sns": {
            "Type": "Notification",
            "MessageId": "67e3f061-7127-5d28-bfa4-a5865480ed69",
            "TopicArn": "arn:aws:sns:us-east-1:999999999999:albtest-sns-1JQJXK25KSW7E",
            "Subject": "OK: \"targetgroup-healthy-host-count\" in US East (N. Virginia)",
            "Message": "{\"AlarmName\":\"targetgroup-healthy-host-count\",\"AlarmDescription\":\"Target Group Healthy Host Monitor\",\"AWSAccountId\":\"639516832405\",\"NewStateValue\":\"OK\",\"NewStateReason\":\"Threshold Crossed: 1 out of the last 1 datapoints [1.0 (02/09/19 21:12:00)] was not less than or equal to the threshold (0.0) (minimum 1 datapoint for ALARM -> OK transition).\",\"StateChangeTime\":\"2019-09-02T21:13:55.934+0000\",\"Region\":\"US East (N. Virginia)\",\"OldStateValue\":\"ALARM\",\"Trigger\":{\"MetricName\":\"HealthyHostCount\",\"Namespace\":\"AWS/ApplicationELB\",\"StatisticType\":\"Statistic\",\"Statistic\":\"AVERAGE\",\"Unit\":null,\"Dimensions\":[{\"value\":\"targetgroup/dynamoc/1cbc7a282793395f\",\"name\":\"TargetGroup\"},{\"value\":\"app/aptest/9c29daf5581bdc46\",\"name\":\"LoadBalancer\"}],\"Period\":60,\"EvaluationPeriods\":1,\"ComparisonOperator\":\"LessThanOrEqualToThreshold\",\"Threshold\":0.0,\"TreatMissingData\":\"- TreatMissingData: notBreaching\",\"EvaluateLowSampleCountPercentile\":\"\"}}",

            "Timestamp": "2019-09-02T14:12:55.995Z",
            "SignatureVersion": "1",
            "Signature": "VvX...FQ==",
            "SigningCertUrl": "https://sns.us-east-1.amazonaws.com/SimpleNotificationService-6aad65c2f9911b05cd53efda11f913f9.pem",
            "UnsubscribeUrl": "https://sns.us-east-1.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:us-east-1:999999999999:albtest-sns-1999999999999:3bf6f089-be25-4e0d-ac95-bdf33fda32bd",
            "MessageAttributes": {}
        }
    }]
}
```
