# Route53 Updater - API Gateway Custom Domain

This template will create a lambda function to handle Route53 UPSERT and DELETE operations when an API Gateway Custom Domain is added or removed from an account.

![Workflow](docs/flow.png)
* pptx source is located in the [docs](docs/) directory.

## Function Details

Both UPSERT and DELETE API actions require a known Route53 Alias.  In the case of the creation, this alias is passed in as part of the event.   For deletion, Route53 must be queried to obtain the current Alias target.

The [list-resource-record-sets](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/route53.html#Route53.Client.list_resource_record_sets) API call is used.  This API has unusual behavior - it cannot return a response for a single name query.   In order to confirm that a record exists, the target domain name is compared against the first record returned by the API call.  If these match the Alias is accquired.  If Route53 returns a `Name` that does not match the domain then that confirms the record is absent.

## Test Events

The following CloudWatch Events can be used to test functionality directly in Lambda.

Adjust the `test.api.domain.com` domain to the desired hostname associated with your hosted zone.

### CreateDomainName

```json
{
  "version": "0",
  "id": "99640a14-a33d-ba49-5c9d-4746602739a3",
  "detail-type": "AWS API Call via CloudTrail",
  "source": "aws.apigateway",
  "account": "639516832405",
  "time": "2019-07-19T20:49:18Z",
  "region": "us-east-1",
  "resources": [],
  "detail": {
    "eventVersion": "1.05",
    "userIdentity": {
      "type": "AssumedRole",
      "principalId": "AROAITCCU5PAJCFCZ4VSA:aperry",
      "arn": "arn:aws:sts::999999999999:assumed-role/privo-support/aperry",
      "accountId": "639516832405",
      "accessKeyId": "ASIAJSTLLHCK5L2YNMFQ",
      "sessionContext": {
        "attributes": {
          "mfaAuthenticated": "false",
          "creationDate": "2019-07-19T20:19:54Z"
        },
        "sessionIssuer": {
          "type": "Role",
          "principalId": "AROAITCCU5PAJCFCZ4VSA",
          "arn": "arn:aws:iam::999999999999:role/privo-support",
          "accountId": "639516832405",
          "userName": "privo-support"
        }
      },
      "invokedBy": "ds.amazonaws.com"
    },
    "eventTime": "2019-07-19T20:49:18Z",
    "eventSource": "apigateway.amazonaws.com",
    "eventName": "CreateDomainName",
    "awsRegion": "us-east-1",
    "sourceIPAddress": "ds.amazonaws.com",
    "userAgent": "ds.amazonaws.com",
    "requestParameters": {
      "createDomainNameInput": {
        "certificateArn": "arn:aws:acm:us-east-1:999999999999:certificate/5c73692a-388d-45ae-821a-8f86a582c96a",
        "domainName": "test.api.domain.com"
      },
      "template": false
    },
    "responseElements": {
      "basepathmappingByBasePath": {
        "domainName": "test.api.domain.com",
        "template": true
      },
      "domainName": "test.api.domain.com",
      "domainnameBasepathmappings": {
        "domainName": "test.api.domain.com",
        "template": true,
        "templateSkipList": [
          "position"
        ]
      },
      "domainnameDelete": {
        "domainName": "test.api.domain.com",
        "template": false
      },
      "distributionDomainName": "d23a972bgzh5lp.cloudfront.net",
      "domainnameUpdate": {
        "domainName": "test.api.domain.com",
        "template": false
      },
      "distributionHostedZoneId": "Z2FDTNDATAQYW2",
      "securityPolicy": "TLS_1_0",
      "endpointConfiguration": {
        "types": [
          "EDGE"
        ],
        "ipv6": false
      },
      "basepathmappingCreate": {
        "domainName": "test.api.domain.com",
        "template": true
      },
      "certificateArn": "arn:aws:acm:us-east-1:999999999999:certificate/5c73692a-388d-45ae-821a-8f86a582c96a",
      "domainNameStatus": "AVAILABLE",
      "certificateUploadDate": "Jul 19, 2019 8:49:18 PM",
      "self": {
        "domainName": "test.api.domain.com",
        "template": false
      }
    },
    "requestID": "5a5a97a4-61b4-4dc4-8290-695336c82453",
    "eventID": "8fdb40d7-10d3-4cb0-8417-5b6ad007b213",
    "readOnly": false,
    "eventType": "AwsApiCall"
  }
}
```

### DeleteDomainName

```json
{
  "version": "0",
  "id": "b347852d-606d-9eff-f661-e1566ca29e49",
  "detail-type": "AWS API Call via CloudTrail",
  "source": "aws.apigateway",
  "account": "639516832405",
  "time": "2019-07-19T21:06:59Z",
  "region": "us-east-1",
  "resources": [],
  "detail": {
    "eventVersion": "1.05",
    "userIdentity": {
      "type": "AssumedRole",
      "principalId": "AROAITCCU5PAJCFCZ4VSA:aperry",
      "arn": "arn:aws:sts::999999999999:assumed-role/privo-support/aperry",
      "accountId": "639516832405",
      "accessKeyId": "ASIAZJZRMOKK6SUVMGNS",
      "sessionContext": {
        "attributes": {
          "mfaAuthenticated": "false",
          "creationDate": "2019-07-19T20:19:54Z"
        },
        "sessionIssuer": {
          "type": "Role",
          "principalId": "AROAITCCU5PAJCFCZ4VSA",
          "arn": "arn:aws:iam::999999999999:role/privo-support",
          "accountId": "639516832405",
          "userName": "privo-support"
        }
      },
      "invokedBy": "ds.amazonaws.com"
    },
    "eventTime": "2019-07-19T21:06:59Z",
    "eventSource": "apigateway.amazonaws.com",
    "eventName": "DeleteDomainName",
    "awsRegion": "us-east-1",
    "sourceIPAddress": "ds.amazonaws.com",
    "userAgent": "ds.amazonaws.com",
    "errorCode": "NotFoundException",
    "errorMessage": "Invalid domain name identifier specified",
    "requestParameters": {
      "domainName": "test.api.domain.com",
      "template": false
    },
    "responseElements": null,
    "requestID": "14e2b49c-20ee-4d92-ad30-2fc113966b64",
    "eventID": "61adc7d8-0fdd-4519-b0af-784daebe9504",
    "readOnly": true,
    "eventType": "AwsApiCall"
  }
}
```
