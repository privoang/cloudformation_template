# S3 Tag on PutObject

This template will create a lambda function to add a tag to an S3 object for every put event where the **file name** begins with `source`.  It is meant to serve as an example for Lambda invocation via S3, and S3 key matching in nodejs.

![Workflow](docs/flow.png)
* pptx source is located in the [docs](docs/) directory.

While this example filters on file name prefix, you can also filter on suffix, which does not require string manipulation.  You can read more about S3 Event Filters [here](https://docs.aws.amazon.com/AmazonS3/latest/dev/NotificationHowTo.html).

## Function Details

The function will extract the filename from the `key` by splitting on `/` if it exists, and grabbing the last element of that array.

If `/` is not found, then the key is an object in the root of the bucket.

The file name is then converted to lowercase and evaluated to begin with `source` in this example.  If matched, a PutObjectTagging API call is executed.

## Test Event

The following CloudWatch Event can be used to test functionality directly in Lambda.

Adjust the bucket name (currently ap-bigdata-labs), and object key (currently some/folder/source.mp4).

Remember that the key must actually exist or the function will throw an exception.


```json
{
  "Records": [
    {
      "eventVersion": "2.1",
      "eventSource": "aws:s3",
      "awsRegion": "us-east-1",
      "eventTime": "2019-07-25T00:11:58.178Z",
      "eventName": "ObjectCreated:Put",
      "userIdentity": {
        "principalId": "AWS:AROAITCCU5PAJCFCZ4VSA:aperry"
      },
      "requestParameters": {
        "sourceIPAddress": "100.0.166.193"
      },
      "responseElements": {
        "x-amz-request-id": "4D9F3CD53F908986",
        "x-amz-id-2": "sKpXNnkUW6pXOOkKcw2iwesMZKo1PFLhKBuB0Y+hyw0HYvQTbeccKCq7NFYBBpQGaUyDhIe2YfA="
      },
      "s3": {
        "s3SchemaVersion": "1.0",
        "configurationId": "4e635f87-2b4f-45af-9f7e-6671e9e6320a",
        "bucket": {
          "name": "ap-bigdata-labs",
          "ownerIdentity": {
            "principalId": "APA7RJJBW1U3J"
          },
          "arn": "arn:aws:s3:::ap-bigdata-labs"
        },
        "object": {
          "key": "some/folder/source.mp4",
          "size": 8,
          "eTag": "eb1a3227cdc3fedbaec2fe38bf6c044a",
          "sequencer": "005D38F3CE1B3AE6FA"
        }
      }
    }
  ]
}
```

