# General Notes and Implementation

## Requirements

- Tag instances with `monitoring-os = X`, where X will be the target of the desired association
- `AmazonCloudWatch-ManageAgent` Association supports target OS
- SSM Agent is installed and running and is connected to the AWS SSM service successfully

## Implementation

The SSM `AmazonCloudWatch-ManageAgent` association pulls the configuration from the SSM Parameter store for the target system's local configuration.

## Extended Functionality

New associations can be configured with new parameter store values to provide more customized configurations.  Tags on instances could be changed to flip configurations.

## References

SSM Association
<https://docs.aws.amazon.com/systems-manager/latest/userguide/systems-manager-associations.html>

Manually Create or Edit the CloudWatch Agent Configuration File
<https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/CloudWatch-Agent-Configuration-File-Details.html>
