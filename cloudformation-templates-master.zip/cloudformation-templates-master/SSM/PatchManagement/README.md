# SSM

## Summary

Templates and supporting files to manipulate instances via SSM.


### Patch Management Template Notes

This is designed to create a patch baseline for critical and important patches for each of the OSes the Amazon offers baselines for.  It will require the SSM Agent to be installed and proper tagging of those instances.  2 Maintenance Windows are defined, one for checking for missing patches and one for applying missing patches.  In the future we may wish to split the patching window and patch groups so patching can be staggered.

Prerequisites for Patch targets:
1. Install SSM and grant IAM role with proper privs
1. Tag instances with a Patch Group tag.

Patch Group values hardcoded in the template:
    *  AmazonLinux
    *  AmazonLinux2
    *  SUSE
    *  Ubuntu
    *  Windows
    *  Redhat
    *  Centos

The Cloudformation template takes these actions:
  Configures Patch Baselines for each Patch Group Tag specified on the template.

  Sets up a maintenance window to schedule for a daily patch baseline scan
  Creates and association for scanning based on the patch baselines

  Sets up a maintenance window to schedule patching
  Creates associations for patching based on the patch baseline

#### Caveats
  For exceptions (those that don't lend themselves to an easy patch baseline)
  Create custom run document to update (patch) or list needed updates (scan)

  For example, run:  apt-get update && apt-get upgrade -force-yes
