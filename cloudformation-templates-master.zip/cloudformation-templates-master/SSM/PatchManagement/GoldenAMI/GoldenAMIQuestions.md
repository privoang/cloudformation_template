# Questions to help define a golden ami pipeline

## Golden AMI

What is the base operating system?
Should it be patched to current and should any OS patches be excluded?

What software should be installed on the golden ami?  Which versions?  
Any custom configs unrelated to the amis usage or deployment environment?

## Golden AMI Pipeline

How often should a new Golden AMI be created?
What workflow should the AMI go through after creation?
For Example: New AMI -> AWS Inspector run -> Staging AMI updated -> Staging tests run -> Wait for approval to update production
