import json
import boto3
import botocore

def lambda_handler(event, context):
    print("Received event:" + " " +
            json.dumps(event, indent=2))

    aminickname = event['aminickname']
    amiid = event['amiid']
    print(amiid)

    ssm = boto3.client('ssm')
    try:
        ssm.put_parameter(Name='/GoldenAMI/' + aminickname +
                            '/latestAMI', Type='String', Value=amiid, Overwrite=True)
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'ParameterNotFound':
            ssm.put_parameter(Name='/GoldenAMI/' + aminickname +
                                '/latestAMI', Type='String', Value=amiid, Overwrite=True)

    return 'updated amiid: ' + amiid
