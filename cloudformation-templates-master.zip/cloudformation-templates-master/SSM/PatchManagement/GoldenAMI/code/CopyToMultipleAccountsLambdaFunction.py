import boto3
import json
from dateutil import parser
import dateutil
import datetime
import collections
import os
import botocore

def lambda_handler(event, context):
    print("Received event:" + " " +
            json.dumps(event, indent=2))

    ssm = boto3.client('ssm',
                        os.environ['AWS_DEFAULT_REGION'])
    accountMetadata = event['MetadataJSON']
    amiRegionMappingParamName = event['MetadataParamName']
    aminickname = event['aminickname']

    #Load the AMI-ID to region mapping in memory.
    amiIDRegionMapping = ssm.get_parameter(Name=amiRegionMappingParamName)[
        'Parameter']['Value']
    mappingJSON = json.loads(amiIDRegionMapping)
    print(mappingJSON)
    roleArnPrefix = 'arn:aws:iam::'
    roleArnSuffix = ':role/${ManagedInstanceRole}'
    amiIDParamNameToCreate = event['AmiIDParamName']
    # loop over account details.
    ssm = boto3.client('ssm')
    ssm.put_parameter(Name=amiIDParamNameToCreate+'/copyMetadata',
                        Value=accountMetadata, Type='String', Overwrite=True)
    SELF_ACCOUNT_ID = context.invoked_function_arn.split(':')[4]
    for accountID, regions in accountMetadata.items():
        if accountID != SELF_ACCOUNT_ID:
            roleArn = roleArnPrefix+accountID+roleArnSuffix
            regionList = regions.split(',')
            for region in regionList:
                amiId = mappingJSON[region]
                ec2Client = boto3.client('ec2',
                                            region)
                ec2Client.modify_image_attribute(ImageId=amiId, LaunchPermission={'Add': [
                                                    {'UserId': accountID}]}, OperationType='add', UserIds=[accountID], Value='string', DryRun=False)
                sts_client = boto3.client('sts')
                assumeRoleOutput = sts_client.assume_role(
                    RoleArn=roleArn, RoleSessionName='AssumeRoleSession1')
                credentials = assumeRoleOutput['Credentials']
                ssm = boto3.client('ssm', region,
                                    aws_access_key_id=credentials['AccessKeyId'],
                                    aws_secret_access_key=credentials['SecretAccessKey'],
                                    aws_session_token=credentials['SessionToken'])
                try:
                    AMIIdsParam = ssm.get_parameter(
                        Name='/GoldenAMI/' + aminickname + '/latestAMI')
                    AMIIds = AMIIdsParam['Parameter']['Value']
                    ssm.put_parameter(Name='/GoldenAMI/' + aminickname +
                                        '/latestAMI', Type='String', Value=AMIIds, Overwrite=True)
                except botocore.exceptions.ClientError as e:
                    if e.response['Error']['Code'] == 'ParameterNotFound':
                        ssm.put_parameter(Name='/GoldenAMI/' + aminickname +
                                            '/latestAMI', Type='String', Value=amiId, Overwrite=True)
                response = ssm.put_parameter(
                    Name=amiIDParamNameToCreate, Value=amiId, Type='String', Overwrite=True)
    return 'Done'
