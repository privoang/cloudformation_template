from __future__ import print_function

import json
import datetime
import time
import boto3
import botocore

print('Loading function')


def lambda_handler(event, context):
    print("Received event:" + " " +
          json.dumps(event, indent=2))

    # get autoscaling client
    ssm = boto3.client('ssm')
    documentname = event['documentname']
    aminickname = event['aminickname']
    kmskeyid = event['kmskeyid']
    autoscalinggroups = event['autoscalinggroups']


    try:
        response = ssm.get_parameter(
            Name='/GoldenAMI/'+aminickname+'/sourceregion')
        print(response['Parameter']['Value'])
        sourceregion = response['Parameter']['Value']
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'ParameterNotFound':
            exit()


########## building the name

    try:
        response = ssm.get_parameter(
            Name='/GoldenAMI/'+aminickname+'/productName')
        print(response['Parameter']['Value'])
        productName = response['Parameter']['Value']
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'ParameterNotFound':
            ssm.put_parameter(Name='/GoldenAMI/'+aminickname+'/productName',
                              Type='String', Value='Base', Overwrite=True)
            productName = 'Base'

    try:
        response = ssm.get_parameter(
            Name='/GoldenAMI/'+aminickname+'/productOSAndVersion')
        print(response['Parameter']['Value'])
        productOSAndVersion = response['Parameter']['Value']
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'ParameterNotFound':
            ssm.put_parameter(Name='/GoldenAMI/'+aminickname+'/productOSAndVersion',
                              Type='String', Value='AmazonLinux-1', Overwrite=True)
            productOSAndVersion = 'AmazonLinux1'

    #amiVersion is now when its being copied
    amiVersion = datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')

    name = productName+"-"+productOSAndVersion+"-"+amiVersion

##########

##amiid
    try:
        response = ssm.get_parameter(
            Name='/GoldenAMI/'+aminickname+'/latestAMI')
        print(response['Parameter']['Value'])
        amiid = response['Parameter']['Value']
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'ParameterNotFound':
            exit(-1)


     


    response = ssm.start_automation_execution(
        DocumentName=documentname,
        Parameters={
            "kmskeyid": [kmskeyid, ],
            "amiid": [amiid, ],
            "sourceregion": [sourceregion, ],
            "name": [name, ],
            "targetASG": [autoscalinggroups, ]

        }
    )
