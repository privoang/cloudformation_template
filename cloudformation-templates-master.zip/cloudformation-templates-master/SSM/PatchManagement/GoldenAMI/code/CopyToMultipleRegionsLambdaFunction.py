import boto3
import json
from dateutil import parser
import dateutil
import datetime
import collections
import os
import botocore

def lambda_handler(event, context):
    print("Received event:" + " " +
            json.dumps(event, indent=2))

    sourceRegion = os.environ['AWS_DEFAULT_REGION']
    ssm = boto3.client('ssm', sourceRegion)
    allRegions = set()
    accountMetadata = event['MetadataJSON']
    amiIDParamName = event['AmiIDParamName']
    aminickname = event['aminickname']
    AMIId = ssm.get_parameter(Name=amiIDParamName)[
        'Parameter']['Value']

    for accountID, regions in accountMetadata.items():
        regionList = regions.split(',')
        for region in regionList:
            allRegions.add(region)

    if sourceRegion in allRegions:
        allRegions.remove(sourceRegion)

    print(allRegions)

    for region in allRegions:
        ssm = boto3.client('ssm', region)
        ssm.put_parameter(Name=amiIDParamName,
                            Value=AMIId, Type='String', Overwrite=True)

    return 'Done'
