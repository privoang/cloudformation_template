from __future__ import print_function

import json
import datetime
import time
import boto3
import botocore

print('Loading function: encryptAMI')


def lambda_handler(event, context):
    print("Received event:" + " " +
          json.dumps(event, indent=2))

    # get ec2 client
    ec2 = boto3.client('ec2')

    print ("Encrypting Image: " + event['amiid'])

    new_ami = ec2.copy_image(
        DryRun=False,
        SourceRegion=event['sourceregion'],
        SourceImageId=event['amiid'],
        KmsKeyId=event['kmskeyid'],
        Encrypted=True,
        Name=event['name'],
        Description="copied from " + event['name']
    )

    return new_ami
    
    # https://boto3.readthedocs.io/en/latest/reference/services/ec2.html#EC2.Client.copy_image
    # response = client.copy_image(
    #     ClientToken='string',
    #     Description='string',
    #     Encrypted=True | False,
    #     KmsKeyId='string',
    #     Name='string',
    #     SourceImageId='string',
    #     SourceRegion='string',
    #     DryRun=True | False
    # )

    #Example event
    # {
    #     kmskeyid: "ebs-us-west-2",
    #     amiid: "ami-xxxx",
    #     sourceregion: "us-east-1",
    #     name: "TreeFiddy"
    # }
