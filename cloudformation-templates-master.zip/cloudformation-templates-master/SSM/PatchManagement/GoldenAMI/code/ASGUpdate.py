from __future__ import print_function

import json
import datetime
import time
import boto3

print('Loading function')

def lambda_handler(event, context):
    print("Received event:" + " " + json.dumps(event, indent=2))

    # get autoscaling client
    client = boto3.client('autoscaling')

    # get object for the ASG we're going to update, filter by name of target ASG
    asg = client.describe_auto_scaling_groups(AutoScalingGroupNames=[event['targetASG']])

    if not asg['AutoScalingGroups']:
        return 'No such ASG'

    # get name of InstanceID in current ASG that we'll use to model new Launch Configuration after
    sourceInstanceId = asg.get('AutoScalingGroups')[0]['Instances'][0]['InstanceId']
    desired = asg.get('AutoScalingGroups')[0]['DesiredCapacity']
    max = asg.get('AutoScalingGroups')[0]['MaxSize']
    lc = client.describe_launch_configurations(LaunchConfigurationNames=[asg.get('AutoScalingGroups')[0]['LaunchConfigurationName']])

    timeStamp = time.time()
    timeStampString = datetime.datetime.fromtimestamp(timeStamp).strftime('%Y-%m-%d-%H-%M-%S')
    newLaunchConfigName = event['targetASG'] + '-' + timeStampString
    
    newlc = lc.get('LaunchConfigurations')[0]
    if max < desired * 2:
        max = 2 * max
    desired = 2 * desired

    newlc['ImageId'] = event['newAmiID']
    newlc['LaunchConfigurationName'] = newLaunchConfigName

    client.create_launch_configuration(
        InstanceId = sourceInstanceId,
        LaunchConfigurationName=newLaunchConfigName,
        ImageId= event['newAmiID'])

    # update ASG to use new LC
    response = client.update_auto_scaling_group(AutoScalingGroupName = event['targetASG'],LaunchConfigurationName = newLaunchConfigName, MaxSize = max, DesiredCapacity= desired )

    print( 'Updated ASG `%s` with new launch configuration `%s` which includes AMI `%s`.' % (event['targetASG'], newLaunchConfigName, event['newAmiID']))
    return response
