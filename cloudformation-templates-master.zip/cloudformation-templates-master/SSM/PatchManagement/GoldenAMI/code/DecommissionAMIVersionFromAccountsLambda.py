import boto3
import json
from dateutil import parser
import dateutil
import datetime
import collections
import os
import time
import botocore

def lambda_handler(event, context):
    sourceRegion = os.environ['AWS_DEFAULT_REGION']
    s3 = boto3.resource('s3')
    prodName = event['productNameAndVersion']
    prodOS = event['productOSAndVersion']
    bucketName = event['bucketName']
    s3FilePrefix = event['templateFileName']
    version = event['versionToBeDeleted']
    aminickname = event['aminickname']
    masterAmis = '/GoldenAMI/'+aminickname+'/latest'
    amiRegionMappingParamName = event['amiRegionMappingParamName']
    prefix = '/GoldenAMI/' + aminickname + '/'+prodOS+'/'+prodName+'/'+version
    ssm = boto3.client('ssm', sourceRegion)
    SELF_ACCOUNT_ID = context.invoked_function_arn.split(':')[
        4]
    try:
        copyMetadata = ssm.get_parameter(Name=prefix+'/copyMetadata')[
            'Parameter']['Value']
        jsonMetadata = json.loads(copyMetadata)
        for accountID, regions in jsonMetadata.items():
            if accountID != SELF_ACCOUNT_ID:
                roleArn = 'arn:aws:iam::'+accountID + \
                    ':role/,{!Ref ManagedInstanceRole""'
                regionList = regions.split(',')
                for region in regionList:
                    sts_client = boto3.client('sts')
                    roleOP = sts_client.assume_role(RoleArn=roleArn, RoleSessionName='ARS1')
                    creds = roleOP['Credentials']
                    ssm = boto3.client('ssm', region, aws_access_key_id=creds['AccessKeyId'], aws_secret_access_key=creds[
                                        'SecretAccessKey'], aws_session_token=creds['SessionToken'])
                    amiID = ssm.get_parameter(Name=prefix)[
                        'Parameter']['Value']
                    temp = ssm.get_parameter(Name=masterAmis)[
                        'Parameter']['Value']
                    temp = temp.replace(amiID+',', '').replace(','+amiID, '').replace(
                        amiID, '')
                    ssm.put_parameter(Name=masterAmis, Type='String', Value=temp, Overwrite=True)
                    ssm.delete_parameter(Name=prefix)
        ssm = boto3.client('ssm',
                            sourceRegion)
        ssm.delete_parameters(Names=[
                                amiRegionMappingParamName, prefix+'/copyMetadata'])
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'ParameterNotFound':
            print('AMI not shared.')
            ssm = boto3.client('ssm',
                                sourceRegion)
            ssm.delete_parameter(Name=prefix)
    return 'Done'

