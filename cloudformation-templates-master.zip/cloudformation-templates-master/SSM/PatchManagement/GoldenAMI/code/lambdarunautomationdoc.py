from __future__ import print_function

import json
import datetime
import time
import boto3
import botocore

print('Loading function')

def lambda_handler(event, context):
    print("Received event:" + " " + json.dumps(event, indent=2))
    
    documentname =event['documentname']
  
    instanceType = event['instancetype']
    aminickname = event['aminickname']
    sourceAMIid = event['sourceamiid']
    productname = event['productname']
    patchgroup = event['patchgroup']
    productOSAndVersion = event['productosandversion']
    accountsandregions = event['accountsandregions']

    # get autoscaling client
    ssm = boto3.client('ssm')

    try:
        response = ssm.get_parameter(
            Name='/GoldenAMI/'+aminickname+'/accountsandregions')
        print(response['Parameter']['Value'])
        accountsandregions = response['Parameter']['Value']
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'ParameterNotFound':
           ssm.put_parameter(Name='/GoldenAMI/'+aminickname+'/accountsandregions',
                             Type='String', Value=str(accountsandregions), Overwrite=True)

    try:
        response = ssm.get_parameter(
            Name='/GoldenAMI/'+aminickname+'/productname')
        print(response['Parameter']['Value'])
        productname = response['Parameter']['Value']
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'ParameterNotFound':
            ssm.put_parameter(Name='/GoldenAMI/'+aminickname+'/productname',
                              Type='String', Value=productname, Overwrite=True)

    try:
        response = ssm.get_parameter(
            Name='/GoldenAMI/'+aminickname+'/productOSAndVersion')
        print(response['Parameter']['Value'])
        productOSAndVersion = response['Parameter']['Value']
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'ParameterNotFound':
            ssm.put_parameter(Name='/GoldenAMI/'+aminickname+'/productOSAndVersion',
                              Type='String', Value=productOSAndVersion, Overwrite=True)

    try:
        response = ssm.get_parameter(
            Name='/GoldenAMI/'+aminickname+'/latestAMI')
        print(response['Parameter']['Value'])
        sourceAMIid = response['Parameter']['Value']
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'ParameterNotFound':
            ssm.put_parameter(Name='/GoldenAMI/'+aminickname+'/latestAMI',
                              Type='String', Value=sourceAMIid, Overwrite=True)

    try:
        response = ssm.get_parameter(Name='/GoldenAMI/'+aminickname+'/productOSAndVersion')
        print(response['Parameter']['Value'])
        productOSAndVersion = response['Parameter']['Value']
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'ParameterNotFound':
            ssm.put_parameter(Name='/GoldenAMI/'+aminickname+'/productOSAndVersion',
                              Type='String', Value=productOSAndVersion, Overwrite=True)

    AMIVersion = datetime.datetime.now().strftime('%Y-%m-%d-%H-%M-%S')

    response = ssm.start_automation_execution(
        DocumentName=documentname,
        Parameters={
            "aminickname": [aminickname, ],
            "sourceAMIid": [sourceAMIid, ],
            "productName": [productname, ],
            "productOSAndVersion": [productOSAndVersion, ],
            "AMIVersion": [AMIVersion, ],
            "instanceType": [instanceType, ],
            "patchgroup": [patchgroup, ]
            
        }
    )

