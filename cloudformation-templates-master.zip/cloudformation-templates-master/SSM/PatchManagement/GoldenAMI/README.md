# Golden AMI Pipeline

## Summary

Templates and python code to create a pipeline for automating AMI patching.

### Patch Management Template Notes

*Requires SSM Patch Baseline*. This is designed to update an ami on a schedule or manual basis.  It will bring up a new ec2 instance from an ami, patch it using an SSM Patch Baseline, create a new ami, copy that ami to other regions, update autoscaling group launch configurations, and scale out to replace those instances with the new ami.


### Setup

Lambda is maintained in the public privo lambda bucket for that region.
        S3Bucket: !Join ["-", ["privo-public-lambda", !Ref "AWS::Region" ]]
        S3Key: "lambda/goldenami/goldenamipipeline.zip"

#### Functions template (GoldenAMIPipelineFunctions):

You'll want to run this template in the region that'll be running the pipeline(s).  

##### Parameters

- subnetPrivate	subnet-5c04ab72  (the subnet the instance is brought up in)

#### AMI Origin Region template  (GoldenAMIPipelineOrigin)

This template can be run multiple times, to maintain multiple OS/Applicaiton images. 

##### Parameters

- pAccountsAndRegions	{"account1":"us-east-1,us-west-2", "account2":"us-west-1"}	
- pAMI	ami-09eff2e35ac2b4319  (this is your starting ami id)	
- pAMINickname	GoldenAMIId	(tied to most resources)
- pInstanceType	t3.micro	(instance size used for patching)
- pLogBucket	052327466433-logs-us-east-1	(logs will be recorded here)
- pPatchGroup	AmazonLinux	(the patch group used from SSM Patch baselines)
- pPipelineFrequency	rate(7 days)	(how often you want the cloudwatch rule that kicks this off to run)
- pProductName	peaches	(descriptor added to ami names)
- pProductOSandVersion	AmazonLinux1	(descriptor added to ami names)
- pSubnetId	subnet-5c04ab72  (subnet where instance is run)

#### AMI Regional Template (GoldenAMIPipelineRegional)

This template is run in every region that is a target for the updated AMI.

##### Parameters

- pAMINickname	GoldenAMIId	
- pAutoScalingGroups	astone-GoldenAMItest  (the name(s) of the autoscaling group(s) that should be automatically updated with the new ami)
- pKmsKeyId	ebs-us-east-1  (kms key alias)
- pSourceRegion	us-east-1

### Kicking it off

The Cloudwatch Rule "origin stack name"-ruleGPSchedule will kick off the pipeline (Cloudwatch->Lambda->Automation).  You can observe progress in the EC2 Console under Automation.  If there's nothing there, you can take the json arguments from the cloudwatch event and feed them into the lambda function as a test event to troubleshoot.


### Updating lambda functions

aws lambda --region us-east-1 --profile privo-dev update-function-code --function-name astone-goldenami-functions-lambdaRunAutomationDoc-1K162QTL84MGJ --s3-bucket privo-public-lambda-us-east-1 --s3-key "lambda/goldenami/goldenamipipeline.zip"
