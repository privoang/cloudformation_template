# Batch

## Summary

Deploys Batch environment with necessary Batch, ECS, and IAM resources.  Allows for the conditional creation of IAM resources if necessary.

The following resources are created by this template:

- On-Demand compute environment
- Spot compute environment
- Batch Job Definition
- Batch Queue
- AWS Batch Service Role
- ECS Instance Role
- ECS Instance Profile

## Overview

This template will create a basic Batch environment with all necessary resources to run both on-demand and spot compute tasks.  Batch requires a set of IAM Roles and AWS Service Roles to exist in order to deploy.  Roles specific to this stack are created here.  The SpotFleet roles can be created by updating the [../IAM/iam-service-roles.yml](../IAM/iam-service-roles.yml) stack and setting the Spot role parameter to "true."

## Requirements

- An ECR must exist before this stack is created.  The base stack for ECR is [../ECS/ecr.yml](../ECS/ecr.yml)

## Pitfalls

You must check the existence of the Spot IAM roles __BEFORE__ you run this stack, otherwise Batch will fail to create and the stack will hang for an hour until it hits timeout and leave resources that can't be deleted until the IAM issues are corrected.  Look at roles in the IAM console and search for Spot to see what exists before deploying.  If the Spot roles do not exist, add them with the [../IAM/iam-service-roles.yml](../IAM/iam-service-roles.yml) stack as mentioned above.
