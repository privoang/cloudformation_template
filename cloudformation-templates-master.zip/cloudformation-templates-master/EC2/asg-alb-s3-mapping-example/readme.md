
# Cloudformation mapping usage to provide flexibility

### Basic rollout:

1. set up a route53 hosted zone 
2. get an ACM cert for that domain
3. Roll out s3 stack
    - drop any config files and bootstrap scripts you need in there (review ec2 stack mapping and userdata for naming and paths)
4. Roll out ALB stack 
    - you may want to drop the hivemq listeners and target groups - they're there for examples
    - update the mappings accordingly
    - grab the target group arn from the outputs
5. Roll out the ASG stack
    - checkout your target group for a good health check, if it fails hop on your instance via SSH or SSM and do a local curl, follow that result and the userdata to the problem.
