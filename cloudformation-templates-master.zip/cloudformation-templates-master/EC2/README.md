# EC2

## Summary
These stacks are used to deploy EC2 instances and related AWS Resources.  Please continue to update this document as you add/modify stacks.

## Stack information

### ad_no_domain.yml

- Creates two EC2 instances with security groups appropriate for domain controllers.
- Windows Server 2016.
- Intended for use when replicating on-prem domain controllers.
- Includes subnet definition for remote local subnet to allows cross-talk.
- For brand-new AWS domains, use `ad.yml`.

### ad.yml

- Creates two EC2 instances as domain controllers with a new AD domain.
- Intended for new domain deploys.
- For deployments where you wish to replicate an existing domain, use `ad_no_domain.yml.`

### alb-cloudfront-wordpress.yml

- ALB, HTTP/HTTPS, with Optional end-to-end SSL. Also creates CloudFront with WordPress specific cache behaviors with ALB as origin.
- This template assumes that WordPress static assets are stored in the local EBS volume. If elsewhere, modify origin and cache behavior appropriately.

### alb-waf-redirectaction

- ALB/WAF template with an example redirect action.

### alb-waf.yml

- ALB/WAF template for most standard deployments.
- WAF is conditional
- Creates TGs and listeners for 80/443

### ec2-asg.yml

- Creates AutoScaling Group for EC2 instances.

### ec2-generic-w-encrypted-data-drives.yml

- Creates EC2 instance with encrypted EBS volumes.

### ec2-generic.yml

- Standard EC2 template for base deployments.
- Conditionally creates SGs
- Conditionally enables AutoRecovery

### ec2-w-cloudwatch-alarms-linux.yml

- Deploys Linux EC2 Instance based on AMI.
- Includes CloudWatch Agents for monitoring (Amazon Linux Userdata).
- Included IAM Role allows SSM Session Manager and CloudWatch reporting

### ec2-w-cloudwatch-alarms-windows.yml

- Deploys Windows EC2 Instance based on AMI.
- Includes CloudWatch Agents for monitoring (Windows Userdata).
- Included IAM Role allows SSM Session Manager and CloudWatch reporting

### enable-autorecovery-on-ec2.yml

- Enables AutoRecovery for an existing EC2 instance.

### linux-bastion.yml

- Amazon Linux bastion host based on region with SSH ingress from single parameterized IP

### nlb.yml

- NLB across 2 AZs with examples.
- Allows for optional EIP assignment per AZ.

### openvpn-amazon-linux-2.yml

- Deploys OpenVPN server in a public subnet from an AmazonLinux2 AMI.
- Allocates and assigns EIP to instance

### openvpn-amazon-linux.yml

- NOTE -- This template is depreciated and should not be used for new deployments.
- Deploys OpenVPN server in a public subnet from a legacy AmazonLinux AMI.
- Allocates and assigns EIP to instance


## Tags

Everything should be tagged if possible.  At a minimum:

- Name
- Environment (Prod, Dev, UAT, etc....)
- Owner

Should be applied to everything if at all possible.  EC2 instances have a larger set of base tags for items such as monitoring, backup, function, etc.... Some customers may want additional tags added for cost/project tracking, among other things.  Add those to the stack in the customer environment, but please make an effort to keep these stacks as generic as possible.
