## General notes

This stack will deploy an Amplify project that tracks a single Github branch.  It will create a Git webhook to automatically launch a build each time a commit is pushed to the branch.

## Requirements

- A Github OATH token with "repo" access and the ability to clone the files.
- The root directory of the Git repo should have a file named `amplify.yml` that contains the commands needed to build the app (sample in this repo).
- a fully-qualified domain name (FQDN) that can be associated with the project

Further documentation can be found here --

https://docs.aws.amazon.com/amplify/latest/userguide/build-settings.html
