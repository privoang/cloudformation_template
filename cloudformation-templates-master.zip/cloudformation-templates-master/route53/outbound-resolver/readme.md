# Route53 Outbound Resolver

This template will create a Route53 outbound resolver, a rule for a single domain, and attach them to a VPC.  The most frequent use of this template would be to forward requests for an Active Directory domain to specific Active Directory servers to facilitate domain joins.

In summary, after deployment, DNS resolution will use AWS DNS servers for everything but the domain we create the forwarder for.

## Considerations

* As of 08/2019, resolvers are 0.125/hr per ENI.  Adding many can add up.  See [pricing](https://aws.amazon.com/route53/pricing/) for current costs.
* Resolvers can be shared via the [Resource Access Manager](https://console.aws.amazon.com/ram/home).
* In order to be highly available, we deploy one resolver endpoint per AZ.
* In this example, we set a single Target IP for the rule.  In the case of multiple domain controllers you may want to set multiple targets.
* Resolvers are **region specific**

## Before Deployment

There is a single resolver rule in each region that is owned by Amazon.  Attention is being called to this so it's clear that this template does not create that and you need not be concerned with it.

![pre-existing rule](docs/existing-rule.png)

## Post Deployment Resolution Tests

The most common use case here will be testing SRV lookups for Active Directory domain joins.

### nslookup

```nslookup
[ec2-user@ip-172-21-10-92 ~]$ nslookup
> set type=SRV
> _ldap._tcp.dc._msdcs.bbq.lan
Server:		172.21.0.2
Address:	172.21.0.2#53

Non-authoritative answer:
_ldap._tcp.dc._msdcs.bbq.lan	service = 0 100 389 EC2AMAZ-38I039D.bbq.lan.

Authoritative answers can be found from:
>
```

### host

```host
[ec2-user@ip-172-21-10-92 ~]$ host -t SRV _ldap._tcp.dc._msdcs.bbq.lan
_ldap._tcp.dc._msdcs.bbq.lan has SRV record 0 100 389 EC2AMAZ-38I039D.bbq.lan.
```
