# General Notes and Implementation

## Requirements

- [kms-service-keys](../IAM/kms-service-keys.yml) CloudFormation stack with AWS Backup KMS key **enabled**.  That key is used via !ImportValue to the [aws-backup stack](aws-backup.yml).
- Review the template [mappings](aws-backup.yml#L33) and configure an entry appropriate for your customer.

## Backup Types

New resources will be added as they're released by AWS.  To keep up to date, refer to the [AWS Backup website](https://docs.aws.amazon.com/aws-backup/latest/devguide/whatisbackup.html).

Currently Available:

- DynamoDB
- EBS
- EC2 Instances (generates an AMI and its corresponding EBS snapshots)
- EFS
- RDS (non-Aurora)
- Storage Gateway

## Implementation

Backup scheduling and targeting is managed via CloudFormation mappings.   A map is selected as part of the stack deployment via the `Backup Configuration` parameter.

![Pick backup schedule](docs/aws-backup-mapping-choices.png)

Before or after deploying the template, tag resources with a backup=`X`.  `X` is the value of `TargetBackupTagValue` in the chosen mapping.

For example, in the `default` map we're looking for instances where the `backup` tag is **yes**.

```yaml
  backups:
    default:
      CompletionWindowMinutes: 480
      DailyCron: "cron(0 1 * * ? *)"
      DailyRetentionDays: 7
      DlmEbsBackupTime: "01:00"
      DlmEbsRetention: 30
      MonthlyCron: cron(0 1 1 * ? *)
      MonthlyRetentionDays: 365
      StartWindowMinutes: 60
      TargetBackupTagValue: "yes"
      WeeklyCron: cron(0 1 ? * SUN *)
      WeeklyRetentionDays: 90
```

Similarly, EC2 instances that will be backed up via DLM will be tagged with dlm=`X`.  `X` is the value of `TargetBackupTagValue` in the chosen mapping.

### Recovery Point Cleanup

AWS hasn't implemented automatic deletion of expired recovery points, so we have added lambda functions to handle that.  A lambda function will run daily, to clear them, so expired is considered DELETED.  There is also a lambda function that can be run manually to purge all recovery points. 

## Extended Functionality

The template can be run multiple times with different scheduling configurations to further customize the environments backups.  Adding configurations to the mapping allows for one template to contain the configuration.  Tagging resources appropriately takes care of the rest.

## Notes

### Tagging

Tagging requirements vary between DLM and AWS Backups.

- DLM requires EC2 _instance_ tags.
- AWS Backups requires tags placed on:
  - DynamoDB Tables
  - EBS volumes
  - EC2 Instances
  - EFS volumes
  - RDS Instances
  - Storage volume gateways

### EFS

Use [aws-backup-efs-cold](aws-backup-efs-cold.yml) if EFS backups will be aged to cold storage.

### Scheduling

DLM is designed to only run daily versus EBS AWS Backups which can run weekly or monthly.

There will be duplicate backups on days the weeklys and monthlys run.  This is minor since only the differences between backups create additional storage costs.

### Data Consistency

EBS AWS Backups **do not do consistent backups across volumes**. This means an instance backup does not necessarily have a backup of each volume from the exact same point in time.

DLM should be used for instances where RAID or databases are in use.  Regardless of AWS level backups, those systems should be considered for an application level backup to S3 as well.

## References

AWS Backup - <https://docs.aws.amazon.com/aws-backup/latest/devguide/whatisbackup.html>

Data Lifecycle Manager - <https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/snapshot-lifecycle.html>
